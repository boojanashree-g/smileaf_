<script src="<?php echo base_url() ?>public/admin/vendor/libs/jquery/jquery.js"></script>
<script src="<?php echo base_url() ?>public/admin/vendor/libs/popper/popper.js"></script>
<script src="<?php echo base_url() ?>public/admin/vendor/js/bootstrap.js"></script>
<script src="<?php echo base_url() ?>public/admin/vendor/libs/node-waves/node-waves.js"></script>
<script src="<?php echo base_url() ?>public/admin/vendor/libs/perfect-scrollbar/perfect-scrollbar.js"></script>
<script src="<?php echo base_url() ?>public/admin/vendor/libs/hammer/hammer.js"></script>
<!-- <script src="<?php echo base_url() ?>public/admin/vendor/libs/i18n/i18n.js"></script> -->
<script src="<?php echo base_url() ?>public/admin/vendor/libs/typeahead-js/typeahead.js"></script>
<script src="<?php echo base_url() ?>public/admin/vendor/js/menu.js"></script>

<!-- endbuild -->

<!-- Vendors JS -->
<script src="<?php echo base_url() ?>public/admin/vendor/libs/apex-charts/apexcharts.js"></script>
<script src="<?php echo base_url() ?>public/admin/vendor/libs/datatables-bs5/datatables-bootstrap5.js"></script>
<script src="<?php echo base_url() ?>public/admin/vendor/libs/form-validation/auto-focus.js"></script>
<script src="<?php echo base_url() ?>public/admin/vendor/libs/form-validation/popular.js"></script>
<script src="<?php echo base_url() ?>public/admin/vendor/libs/form-validation/bootstrap5.js"></script>
<script src="<?php echo base_url() ?>public/admin/vendor/libs/select2/select2.js"></script>

<!-- Helpers -->
<script src="<?php echo base_url() ?>public/admin/vendor/js/helpers.js"></script>
<!-- <script src="<?php echo base_url() ?>public/admin/vendor/js/template-customizer.js"></script> -->
<script src="<?php echo base_url() ?>public/admin/js/config.js"></script>
<!-- Main JS -->
<script src="<?php echo base_url() ?>public/admin/js/main.js"></script>
<!-- Page JS -->
<script src="<?php echo base_url() ?>public/admin/js/pages-auth.js"></script>
<script src="<?php echo base_url() ?>public/admin/js/app-ecommerce-product-list.js"></script>



<!-- Page JS -->
<script src="<?php echo base_url() ?>public/admin/js/app-ecommerce-dashboard.js"></script>
<!-- <script src="<?php echo base_url() ?>public/admin/js/app-access-permission.js"></script> -->
<!-- <script src="<?php echo base_url() ?>public/admin/js/modal-add-permission.js"></script>
<script src="<?php echo base_url() ?>public/admin/js/modal-edit-permission.js"></script> -->
<!-- <script src="<?php echo base_url() ?>public/admin/js/ui-modals.js"></script> -->

<!-- DATATABLES CDN JS -->
<script src="https://cdn.datatables.net/1.12.1/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.12.1/js/dataTables.bootstrap5.min.js"></script>
<script src="https://cdn.datatables.net/responsive/2.3.0/js/dataTables.responsive.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.2.3/js/dataTables.buttons.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.2.3/js/buttons.print.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.2.6/pdfmake.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script>
<script src="https://cdn.datatables.net/buttons/2.2.3/js/buttons.html5.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.10.1/jszip.min.js"></script>

<!-- <! Custom js---->
<script src="<?php echo base_url() ?>custom/js/activeSidenav.js"></script>



<!-- Dropzone -->
<script src="<?php echo base_url() ?>public/admin/vendor/libs/dropzone/dropzone.js"></script>

<!-- SweetAlert2 JS -->
<script src="<?php echo base_url() ?>public/admin/js/extended-ui-sweetalert2.js"></script>
<script src="<?php echo base_url() ?>public/admin/vendor/libs/sweetalert2/sweetalert2.js"></script>
<script src="<?php echo base_url() ?>public/admin/js/forms-file-upload.js"></script>

<script src="<?php echo base_url() ?>public/admin/js/offcanvas-send-invoice.js"></script>

<script src="<?php echo base_url() ?>public/admin/vendor/libs/moment/moment.js"></script>
<script src="<?php echo base_url() ?>public/admin/vendor/libs/flatpickr/flatpickr.js"></script>
<script src="<?php echo base_url() ?>public/admin/vendor/libs/cleavejs/cleave.js"></script>
<script src="<?php echo base_url() ?>public/admin/vendor/libs/cleavejs/cleave-phone.js"></script>